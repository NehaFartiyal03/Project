function cleanLatex(content) {
  return content
    // remove IEEE blocks
    .replace(/\\IEEEauthorblockN\{([^}]*)\}/g, "$1")
    .replace(/\\IEEEauthorblockA\{([^}]*)\}/g, "")

    // remove symbols *, †, etc
    .replace(/\*/g, "")
    .replace(/\\\(\{ \}\^\{.*?\}\\\)/g, "")

    // remove emails
    .replace(/\S+@\S+/g, "")

    // clean extra stuff
    .replace(/Student Member, IEEE/g, "")
    .replace(/Member, IEEE/g, "")

    // keep only simple author
    .replace(/\\author\{([^}]*)\}/g, (match, p1) => {
      const names = p1.split(",");
      return `\\author{${names.slice(0, 3).join(",")}}`; // limit authors
    });
}

module.exports = cleanLatex;