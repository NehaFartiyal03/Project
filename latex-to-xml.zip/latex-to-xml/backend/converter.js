const { exec } = require('child_process');
const path = require('path');

function runCommand(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) reject(stderr);
      else resolve(stdout);
    });
  });
}

async function convertLatexToXML(inputFile) {
  const baseName = path.basename(inputFile, '.tex');
  const outputFile = `outputs/${baseName}.xml`;

  const command = `perl ../LaTeXML-master/blib/script/latexml --dest=${outputFile} ${inputFile}`;

  await runCommand(command);

  return outputFile;
}

module.exports = { convertLatexToXML };