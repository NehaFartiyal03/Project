const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(express.json());

// folders ensure
if (!fs.existsSync("uploads")) fs.mkdirSync("uploads");
if (!fs.existsSync("outputs")) fs.mkdirSync("outputs");

// static serve
app.use("/outputs", express.static(path.join(__dirname, "outputs")));

// multer setup
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + ".tex");
  },
});
const upload = multer({ storage });

// import cleaner
const cleanLatex = require("./cleaner");

// ROUTE
app.post("/upload", upload.single("file"), (req, res) => {
  try {
    console.log("📥 File received");

    const inputPath = req.file.path;
    const outputFile = Date.now() + ".xml";
    const outputPath = path.join("outputs", outputFile);

    // 🔥 STEP 1: read latex
    let content = fs.readFileSync(inputPath, "utf-8");

    // 🔥 STEP 2: clean latex (VERY IMPORTANT)
    content = cleanLatex(content);

    // overwrite cleaned file
    fs.writeFileSync(inputPath, content);

    console.log("🧹 LaTeX cleaned");

    // 🔥 STEP 3: pandoc command
    const command = `pandoc "${inputPath}" -f latex -t docbook --mathml -s -o "${outputPath}"`;

    console.log("⚙️ Running pandoc...");

    exec(command, (error, stdout, stderr) => {
      console.log("STDOUT:", stdout);
      console.log("STDERR:", stderr);

      if (error) {
        console.log("❌ ERROR:", error);
        return res.json({
          success: false,
          error: stderr,
        });
      }

      // 🔥 STEP 4: check file exists
      if (!fs.existsSync(outputPath)) {
        console.log("❌ XML not created");
        return res.json({
          success: false,
          error: "XML file not created",
        });
      }

      const stats = fs.statSync(outputPath);

      if (stats.size === 0) {
        console.log("❌ XML empty");
        return res.json({
          success: false,
          error: "XML file is empty",
        });
      }

      console.log("✅ Conversion done");

      res.json({
        success: true,
        file: `http://localhost:3000/outputs/${outputFile}`,
      });
    });

  } catch (err) {
    console.log("❌ SERVER ERROR:", err);
    res.json({
      success: false,
      error: "Server error",
    });
  }
});

// TEST route
app.get("/", (req, res) => {
  res.send("Backend Working ✅");
});

// server start
app.listen(3000, () => {
  console.log("🚀 Server running on http://localhost:3000");
});