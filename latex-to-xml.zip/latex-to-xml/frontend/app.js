async function uploadFile() {
  const fileInput = document.getElementById("fileInput");
  const file = fileInput.files[0];

  if (!file) {
    alert("Please select a file");
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  document.getElementById("status").innerText = "Processing...";

  try {
    const res = await fetch("http://localhost:3000/upload", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();

    if (data.success) {
      document.getElementById("status").innerHTML =
        `✅ Done <br><a href="${data.file}" target="_blank">Download XML</a>`;
    } else {
      document.getElementById("status").innerText = "❌ Failed";
    }
  } catch (err) {
    console.log(err);
    document.getElementById("status").innerText = "❌ Server Error";
  }
}